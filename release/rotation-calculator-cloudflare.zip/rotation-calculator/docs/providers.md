# ბაზრის მონაცემების წყარო (ADR-003)

განახლდა: 2026-10-30 (რეალური გაშვების შედეგებით). წინა ვერსიები (Numbeo-ს ოფიციალური API, Eurostat) — git-ის ისტორიაში; პროდუქტიდან ამოღებულია.

## 1. გადაწყვეტილება

| საკითხი | გადაწყვეტა |
| --- | --- |
| წყარო | Numbeo.com-ის გვერდები, მოპოვებული Apify actor-ით **`automation-lab/numbeo-scraper`** |
| სად სრულდება | მხოლოდ Cloudflare Worker-ში (`/api/market`). ბრაუზერი Apify-ს/Numbeo-ს პირდაპირ არ უკავშირდება |
| ავთენტიფიკაცია | `APIFY_TOKEN` — Cloudflare Secret (ლოკალურად `.dev.vars`), `Authorization: Bearer` სათაურით; არასოდეს URL-ში, ლოგში, git-ში, `dist/`-ში ან არქივში (ამოწმებს `tests/providers/no-secrets.test.js`) |
| ქეში | 30 დღე (`MARKET_CACHE_TTL_DAYS`), Workers KV `MARKET_CACHE`; ინდექსები (`rankings`) — ერთი გაშვებით ყველა ქალაქზე |
| გამორთვა | `MARKET_PROVIDER=off` → გვერდზე „ბაზრის მონაცემები გამორთულია“; გამოთვლები უცვლელად მუშაობს |
| ატრიბუცია | „წყარო: Numbeo.com (მოპოვებულია Apify-ის მეშვეობით)“ + ბმული ქალაქის გვერდზე |

## 2. რისკი, რომელიც მომხმარებელმა იცის

- Numbeo-ს გამოყენების პირობები (terms_of_use.jsp) **კრძალავს ავტომატურ მონაცემთა შეგროვებას (scraping) წერილობითი ნებართვის გარეშე** და მონაცემის ხელახალ გავრცელებას სხვა API-ით/საჯარო ნაკადით. მესამე მხარის actor (Apify) ამ პირობებს არ ცვლის და უფლებას არ ქმნის.
- გადაწყვეტილება მიიღო მომხმარებელმა (ADR-003). კოდი ამიტომ: აჩვენებს წყაროს, არ ქმნის საჯარო API-ს (მხოლოდ შიდა ID + EUR/USD), ზღუდავს მოთხოვნებს (rate limit, 30-დღიანი ქეში) და აქვს ერთი ცვლადით გამორთვა.
- Numbeo-ს ოფიციალური API (ფასიანი, Basic 260 USD/თვე 2026-10-29-ის მონაცემით) უფრო სუფთა სამართლებრივი გზაა, მაგრამ საჯარო საიტზე ხელახალი ჩვენებისთვისაც Numbeo-ს თანხმობას საჭიროებს.

## 3. Apify actor — დადასტურებულია რეალური გაშვებით (2026-10-30)

| საკითხი | ფაქტი |
| --- | --- |
| Endpoint | `POST https://api.apify.com/v2/acts/automation-lab~numbeo-scraper/run-sync-get-dataset-items?timeout=<წმ>`, `Authorization: Bearer`; წარმატება HTTP 201, ტანი = სტრიქონების მასივი |
| `city_prices` | შესავალი `{ mode: "city_prices", cities: ["Vienna"], currency: "EUR" }`. გამოსავალი — **ბრტყელი** სტრიქონები `{ city, country, category, item, price, currency, range: "12.00-26.00" \| "1,800.00-3,000.00" \| "", url, scrapedAt }` (ვენა: 55 სტრიქონი). `range` → low/high (ათასეულის მძიმე იშლება; ცარიელი → null). ამ რეჟიმში ინდექსები არ არის |
| ქალაქის სახელი შესავალში | actor სახელს URL slug-ად აქცევს: **„Washington, DC“ → HTTP 400**; „Washington“ → 201. ამიტომ შესავალში იგზავნება სახელი „, XX“ სუფიქსისა და ფრჩხილების გარეშე (`pricesQueryFor`), შედარებისთვის კი — სრული Numbeo სახელი |
| `rankings` | `{ mode: "rankings", maxCities: 0 }` → **ყველა 547 ქალაქი** (~6 წმ); სტრიქონი `{ rank, city, country, costOfLivingIndex, rentIndex, costOfLivingPlusRentIndex, groceriesIndex, restaurantPriceIndex, localPurchasingPowerIndex, url }`. ნაგულისხმევი `maxCities` = 50 (ამიტომ ვენა თავიდან არ ჩანდა). დამთხვევა: ზუსტი Numbeo სახელი + ქვეყანა |
| `comparison` | 1 და 2 ქალაქზე ჩავარდა — არ გამოიყენება |
| თარიღი | წყაროს განახლების თარიღი არ არის; `scrapedAt` = მიღების დრო → `sourceUpdatedAt = null` |

ერთეულების ზუსტი სახელები (მიმდინარე; ძველი დაწერილობა რჩება fallback-ად):
- ქირა (Rent Per Month): „1 Bedroom Apartment in City Centre“, „1 Bedroom Apartment Outside of City Centre“, „3 Bedroom Apartment in City Centre“, „3 Bedroom Apartment Outside of City Centre“.
- კომუნალური (Utilities (Monthly)): „Basic Utilities for 85 m2 Apartment (Electricity, Heating, Cooling, Water, Garbage)“ — **აშშ-ში: „Basic Utilities for 915 Square Feet Apartment (…)“** (915 sq ft ≈ 85 მ²; დადასტურდა ვაშინგტონზე); „Broadband Internet (Unlimited Data, 60 Mbps or Higher)“.
- რესტორნები: „Meal at an Inexpensive Restaurant“, „Meal for Two at a Mid-Range Restaurant (Three Courses, Without Drinks)“.
- **სურსათი — „ძირითადი სასურსათო ჩამონათვალი (ალკოჰოლისა და თამბაქოს გარეშე)“**: „Markets“ კატეგორიის (19 ერთეული) საშუალო ფასების ზუსტი ჯამი, **გარდა**: „Bottle of Wine (Mid-Range)“, „Domestic Beer (0.5 Liter Bottle)“, „Imported Beer (0.33 Liter Bottle)“, „Cigarettes (Pack of 20, Marlboro)“ (+ დამცავი საკვანძო სიტყვები wine/beer/cigarette/tobacco). ფასის არმქონე ერთეული → `itemsMissing`, ჯამში არ შედის (არასოდეს 0).

ქალაქების სახელები (`numbeo-city-names.json`): 81-დან **76 დადასტურდა** Numbeo-ს რეალური rankings სიით (547 ქალაქი; `verifiedBy: "rankings 2026-10-30"`), მათ შორის შესწორებული: Frankfurt, Krakow (Cracow), Chisinau, Brasilia, Delhi, Kiev (Kyiv), Odessa (Odesa), Astana (Nur-Sultan). rankings-ში **არ არის** (ინდექსები → not_found, ფასები შეიძლება იყოს): Trabzon, Ganja, Ashgabat, Donetsk, Havana — `verified:false`. ვატიკანი → რომი (`nearby-explained`).

## 4. ღირებულება (Apify, actor pay-per-event, უფასო ტარიფზე; გადამოწმდა 2026-10-30)

| მოქმედება | ფასი |
| --- | --- |
| გაშვების დაწყება | $0.01 |
| თითო დამუშავებული ქალაქი | $0.005 |
| ერთი ქალაქის `city_prices` | ≈ $0.015 |
| სრული `rankings` (547 ქალაქი) | ≈ $2.745 |

30-დღიანი ქეშით: rankings ≈ **$2.75/თვე** + ≈ $0.015 თითო ქალაქზე და ვალუტაზე 30 დღეში (81 ქალაქი × 1 ვალუტა ≤ $1.22). ინდექსების გამორთვა კრედიტის დასაზოგად: `MARKET_RANKINGS_ENABLED="false"` (ფასები რჩება, `indices.status = "disabled"`). ფასები Apify-ის/actor-ის ტარიფია და შეიძლება შეიცვალოს — გადაამოწმეთ Apify Console-ში.

ხელახალი შემოწმება (იაფად, rankings-ის გარეშე): `NODE_USE_ENV_PROXY=1 node scripts/live-check-apify.mjs AT-VIENNA --currency=EUR --rankings-file=<rankings.json>` (ან `--skip-rankings`).

## 5. ხელით შეყვანა

რჩება ოფლაინ ფაილისთვის და წყაროს არქონისას: ხელით ფორმა და ვალიდირებული JSON იმპორტი (`kind: "market-import"`, `schemaVersion: 2`), status „ხელითაა შეყვანილი“. შეყვანილი ქირა `G`-ში მხოლოდ მომხმარებლის ღილაკით გადადის.

## 6. ყოველთვიური ფონური განახლება, ასლი და დედაქალაქის წესი (რაუნდი 4, 2026-11-04)

**როგორ მიდის მონაცემი მომხმარებლამდე** (`MARKET_ON_DEMAND="false"`, ნაგულისხმევი — მომხმარებლის მოთხოვნა Apify-ს **არ** იძახებს):
1. KV-ში ქალაქის ახალი ჩანაწერი (≤ 30 დღე) → „შენახული მონაცემია“;
2. KV-ის ვადაგასული ჩანაწერი (≤ `MARKET_STALE_MAX_DAYS`) → „მოძველებულია“;
3. ჩაშენებული ასლი `src/data/market-snapshot.json` (76 ქალაქი, 31.10.2026, USD) → გაფრთხილება „შენახული მონაცემი, 31.10.2026“;
4. **დედაქალაქის წესი:** თუ ქალაქს საკუთარი მონაცემი არ აქვს — ნაჩვენებია ქვეყნის დედაქალაქის (საქართველოს საელჩოს ქალაქის) მონაცემი, `matchStatus: "capital-fallback"`, „ქალაქის მონაცემი არ მოიძებნა — ნაჩვენებია დედაქალაქის (…) მონაცემი“. თუ მხოლოდ ერთი კატეგორია აკლია — ის კატეგორია დედაქალაქიდანაა (`fallback: true`). დედაქალაქი: `src/providers/capitals.json` (`node scripts/gen-capitals.mjs`; გამონაკლისები: ვატიკანი → რომი, რუსეთი → მოსკოვი (ინტერესების სექცია), სერბეთი → ბელგრადი; საელჩო არა დედაქალაქში: ნიდერლანდები — ჰააგა, ისრაელი — თელ-ავივი). მაგ.: განჯა → ბაქო, ტრაბზონი → ანკარა, სტრასბურგი → პარიზი, შტუტგარტი → ბერლინი.
5. არაფერი → „ფასები მალე განახლდება“ (`pending_refresh`).

**ვალუტა:** მონაცემი ყოველთვის მოდის მისიის დაფინანსების ვალუტაში. ასლი USD-შია; EUR მისიისთვის თანხები გადაიყვანება ზუსტად `usdPerEur.exact` წილადით (1 EUR = 1.119954 USD, Numbeo-ს € პარალელების მედიანა), 2 ათწილადამდე, გაფრთხილებით „≈ გადაყვანილია Numbeo-ს კურსით … — საორიენტაციოდ“. ინდექსები არ გადაიყვანება. **ბიუჯეტი** (თვიური ხარჯი ქირის გარეშე: 1 პირი / 4-სულიანი ოჯახი) მხოლოდ ასლშია — KV-ის Apify მონაცემს ემატება ასლიდან, თავისი თარიღით.

**ყოველთვიური განახლება (Cron, `worker/refresh.js`):** ყოველ 15 წუთში ერთი მცირე ნაბიჯი. როცა `nextRefreshAt` დადგება: იწყება 3 ასინქრონული Apify გაშვება — ყველა EUR ქალაქი ერთ გაშვებაში (42), ყველა USD ქალაქი (37), rankings (547 ქალაქი, ინდექსები). შემდეგ ნაბიჯებზე: სტატუსის შემოწმება და dataset-ის თითო გვერდი (≈ 2 ქალაქი) → KV. ცარიელი ქალაქი არ იწერება (წინა კარგი ასლი რჩება; წაკითხვისას — დედაქალაქის წესი). დასრულების შემდეგ შემდეგი განახლება 30 დღეში (`MARKET_REFRESH_DAYS`). შეცდომა გაშვებისას (402 კრედიტი ამოიწურა, 401/403, 429, 5xx) → შემდეგი ცდა 1 დღეში; ერთდროულად მხოლოდ ერთი სამუშაო.

**ღირებულება თვეში:** ქალაქების 2 გაშვება ≈ 2 × $0.01 + 79 × $0.005 ≈ **$0.42** + rankings ≈ **$2.745** → **≈ $3.16/თვე** (Apify-ის უფასო $5/თვე ლიმიტში). ინდექსების გამორთვით (`MARKET_RANKINGS_ENABLED="false"`) ≈ $0.42/თვე.

**მდგომარეობა:** `/api/market/health` → `refresh: { state, lastRefreshAt, nextRefreshAt, populatedCities, lastErrorCode, lastSummary }`, `snapshot: { cities, retrievedAt }`, `onDemand`.

## 7. რეალური ბათჩ-გაშვება 2026-11-04 და Apify-ის ასლი

**შედეგი (მეორე Apify ანგარიში, ≈ $3.16; დარჩა ≈ $1.85 ამ თვეში):** EUR ბათჩი — 41 ქალაქი (Krakow ვერ მოიძებნა), USD — 28 + დამატებითი 8 (Astana, Beijing, Addis Ababa, Abu Dhabi, Hanoi, San Francisco, Havana, „Gence“ = განჯა), rankings — 547 ქალაქი. სულ **77 ქალაქი** ფასებით (`numbeo-city-names.json` → `apifyVerified: "2026-11-04"`).

**actor-ის ქცევა, რაც უნდა ვიცოდეთ:**
- **პირველივე ვერნაპოვნ ქალაქზე მთელი გაშვება ჩერდება** (run FAILED; მანამდე მოპოვებული ქალაქები dataset-ში რჩება). Donetsk-მა USD ბათჩი შეაჩერა; „Krakow“ ცალკეც ვერ იძებნება. ამიტომ: cron-ის ძირითადი ბათჩები მხოლოდ `apifyVerified` ქალაქებით; Donetsk, Krakow, ვატიკანი — `apifyExclude` (ჩვენებისას: Donetsk → კიევი, Krakow → მომხმარებლის ასლი, ვატიკანი → რომი); დაუდასტურებელი ქალაქი — ცალკე, პატარა, ბოლო გაშვებაში; FAILED გაშვების მიღებული სტრიქონებიც მუშავდება.
- ქალაქის სახელი შესავალში შეიძლება განსხვავდებოდეს (განჯა → „Gence“, `pricesQuery`).
- ამ გაშვებამ ერთეულები **იმპერიულში** დააბრუნა („Chicken Fillets (1 lb)“, „Fresh White Bread (1 lb Loaf)“, „Bottled Water (50 oz)“, „Basic Utilities for 915 Square Feet …“). სასურსათო კალათა ყოველთვის მეტრულია (1 კგ, 500 გ პური, 1.5 ლ წყალი — როგორც მომხმარებლის ასლში): ფასი გადაიყვანება ზუსტი კოეფიციენტით (×2.20462262, ×1.10231131, ×1.01442058); უცნობი იმპერიული ერთეული ჯამში არ შედის. შემოწმება: ვენის კალათა 71.35 € (Apify) vs 71.97 € (მომხმარებლის ასლი, 31.10).

**ასლი `src/data/market-apify-snapshot.json`** (`node scripts/build-apify-snapshot.mjs --eur=EUR.json --usd=USD.json --usd=USD2.json --rank=RANK.json --fetched=2026-11-04`): 78 ქალაქი (77 ფასებით + Krakow მხოლოდ ინდექსებით), მისიის დაფინანსების ვალუტაში, მხოლოდ საჭირო ბლოკები (ნედლი სტრიქონები არა). წარწერა: „შენახული მონაცემი · 04.11.2026“.

**წყაროების რიგი (თითო კატეგორიაზე):** KV (cron/live) → Apify-ის ასლი (04.11.2026) → მომხმარებლის ასლი (31.10.2026; ბიუჯეტი მხოლოდ აქ) → დედაქალაქის წესი → `pending_refresh`. კატეგორია, რომელსაც მხოლოდ ინდექსი აქვს (მაგ. Krakow-ის ქირა), ჩანაცვლდება შემდეგი წყაროს რეალური თანხებით.

**Cron-ის დაცვა:** `MARKET_FIRST_REFRESH_AFTER = "2026-12-01"` — ამ თარიღამდე Apify არ გამოიძახება (განთავსებულ Secret-ში ჯერ ძველი, ამოწურული ანგარიშის ტოკენია; ახალი ანგარიშის ≈ $1.85 ნოემბერში არ დაიხარჯოს). დეკემბრიდან ყოველთვიური ხარჯი ≈ $3.16 (ქალაქები ≈ $0.42 + rankings $2.745).

## 8. „ქალაქების სიძვირე“ — `GET /api/market/summary?v=1` (რაუნდი 5)

ყველა მისიის ქალაქი (80) ერთ პასუხში: `{ schemaVersion: 1, generatedAt, rows: [{ locationId, city_ka, country_ka, currency (მისიის), indices { costOfLivingPlusRent, costOfLiving, rent }, rentCentre1br, source: "kv"|"apify-snapshot"|"user-snapshot"|"capital", sourceDate, fallbackFrom? }] }`. თითო ველზე იგივე რიგი (KV → Apify-ის ასლი → მომხმარებლის ასლი → დედაქალაქი); `fallbackFrom` — თუ რომელიმე ველი დედაქალაქიდანაა. KV-ის ქეში `summary:v1` 12 სთ, cron-ის დასრულებისას უქმდება; Apify არ გამოიძახება. კლიენტი: `createMarketClient().summary()` (შეცდომისას `null`) და `marketSummaryFromSnapshots(userSnapshot, apifySnapshot, normativeData)` (file://).

## 9. მონაცემთა შესწორებები და ბიუჯეტის შეფასება (რაუნდი 5)

- **Odesa:** შესავალი „Odessa“ actor-მა ტეხასის ოდესად (აშშ) გაიგო → ფასის სტრიქონები ახლა მოწმდება ქვეყანაზეც (`numbeoCountry`); UA-ODESA — `apifyExclude` (ფასები მომხმარებლის ასლიდან). **Astana:** ფასები KZT-ში „USD“ ნიშნით → დამაჯერებლობის დაცვა: იაფი სადილი > 150 ან ქირა > 20 000 EUR/USD, ან ქირა > 3× / < ⅓ საცნობაროსთან (მომხმარებლის ასლი / KV-ის წინა ასლი) ⇒ ქალაქის Apify ფასები უარყოფილია (`implausible_value`), გამოიყენება შემდეგი წყარო. მოქმედებს `build-apify-snapshot.mjs`-შიც და cron-შიც. ასლის ხელახალი აწყობის შემდეგ არცერთი ქალაქის ქირა მომხმარებლის ასლისგან 1.5×-ზე მეტად არ განსხვავდება.
- **ბიუჯეტი ყველა ქალაქისთვის:** Numbeo-ს რეალური ბიუჯეტი 41 ქალაქს აქვს (`basis: "numbeo"`). დანარჩენისთვის `budget = NYC ბიუჯეტი × costOfLiving / 100` (`basis: "estimated-from-index"`, `estimated: true`, `budget_estimated`). NYC-ის ბიუჯეტი მომხმარებლის ასლში ცარიელია, ამიტომ საცნობარო მნიშვნელობაა 41 რეალური ბიუჯეტის „ნაგულისხმევი NYC“ (ბიუჯეტი × 100 / ინდექსი) მედიანა — ერთი პირი ≈ 1672.97 USD, 4-სულიანი ოჯახი ≈ 5946.55 USD (გაბნევა ±8%). ყველაფერი ზუსტი რაციონალებით, EUR — `usdPerEur.exact`. შეჯამების სტრიქონებში: `budget: { single, family4, basis, fromCapital }`.
